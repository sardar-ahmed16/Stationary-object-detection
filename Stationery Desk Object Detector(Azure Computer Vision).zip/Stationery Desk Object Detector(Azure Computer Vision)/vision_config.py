# Replace with your Azure credentials
AZURE_ENDPOINT = "https://vision52939715.cognitiveservices.azure.com/"
AZURE_KEY = "9cleZsWkg4Hhe13VuXvcEC5vTzPODDthRmVUgb36LU8n79TfTHWYJQQJ99BGACqBBLyXJ3w3AAAFACOGEuCr"
